package basic.day2;

/*      문제:
 *      ++ 연산자와 println()을 여러번 사용해서
 *      char start='A'; 로 합니다.
 *      1. A~Z 까지 출력하기
 * 
 *      2. Z~A 까지 출력하기
 */

public class ProbAlpahbetPrint {
    
    public static void main(String[] args) {
        
        char start='A';
        System.out.println("A~Z까지 출력하기");
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);
        System.out.print(start++);

        System.out.println("\nZ~A까지 출력");
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
        System.out.print(--start);
    }
}
