package object.day5;
//B03, Score 2개 파일 구글드라이브에 올려주세요
public class B03ScoreMain {
    public static void main(String[] args) {
        
        //학생 4명의 성적을 저장해보세요. -객체 4개
        // 1학년 2명(모모,다현) 3과목   
        // 2학년 2명(나연,쯔위) 4과목
        // 점수는 마음대로 저장하세요.




    }
}
