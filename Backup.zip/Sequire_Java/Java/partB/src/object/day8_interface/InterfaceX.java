package object.day8_interface;

public interface InterfaceX {
	//추상클래스 선언. public abstract 생략
	String methodX();
}
