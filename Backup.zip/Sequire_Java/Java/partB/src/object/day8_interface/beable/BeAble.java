package object.day8_interface.beable;

@FunctionalInterface
public interface BeAble {		//할 수있는
	String beAble(); 
}


interface InrBeAble {
	//public 이 아닌 인터페이스를 하나 더 정의할 수 있습니다.
	// 한 개의 파일에 여러개 클래스 또는 인터페이스 정의 가능함.
	
}
