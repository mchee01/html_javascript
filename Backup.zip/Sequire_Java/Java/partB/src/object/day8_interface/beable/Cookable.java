package object.day8_interface.beable;

// 인터페이스끼리 상속 가능합니다.
public interface Cookable extends BeAble{

	void cook(String material);		//요리하다.
	default void prepare(){
		
	}
}
