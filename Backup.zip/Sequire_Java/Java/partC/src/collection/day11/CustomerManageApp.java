package collection.day11;

//1월14일 저녁 9시까지 제출해주세요.-구글 드라이브 폴더에 
public class CustomerManageApp {
    //JavaWordApp V2 형식으로 하세요.
    

    public static void main(String[] args) {
        CustomerManageApp app = new CustomerManageApp();
        app.start();
    }

    private void start() {
        //메뉴 선택 : 등록,검색(이름/그룹), 삭제,수정,전체출력

    }
}
