package collection.day13;
//socket.png 그림참고: 클라이언트와 서버 가각 실행하는 메소드가 다름.
//                      서버와 클라이언트 연결 과정이 다르기 때문에.
public class Client {

}
